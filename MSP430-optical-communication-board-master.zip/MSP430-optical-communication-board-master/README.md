# MSP430-optical-communication-board
This codes contains codes on different applications
